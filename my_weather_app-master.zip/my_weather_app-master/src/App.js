import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import WeekContainer from './WeekContainer';

class App extends Component {
  render() {
    return (
      <div className="App">
        < WeekContainer />
      </div>
    );
  }
}

export default App;
